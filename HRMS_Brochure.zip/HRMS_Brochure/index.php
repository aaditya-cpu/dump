<?php include 'includes/header.php'; ?>

<!-- Add your main page content here -->
<div class="container">

<div id="conversation">
    <div class="bubble-container">
        <div class="bubble">
            <p>So you want to Manage your employees, staff, salaries?</p>
        </div>
        <div class="bubble-options">
            <button class="option" data-answer="yes">Yes</button>
            <button class="option" data-answer="no">No</button>
        </div>
    </div>
</div>
<div id="answer"></div>

</div>

<?php include 'includes/footer.php'; ?>
