# Create directories
New-Item -ItemType Directory -Force -Path HRMS_Brochure/assets/images
New-Item -ItemType Directory -Force -Path HRMS_Brochure/assets/css
New-Item -ItemType Directory -Force -Path HRMS_Brochure/assets/js
New-Item -ItemType Directory -Force -Path HRMS_Brochure/includes

# Create files
New-Item -ItemType File -Force -Path HRMS_Brochure/assets/css/style.css
New-Item -ItemType File -Force -Path HRMS_Brochure/assets/js/script.js
New-Item -ItemType File -Force -Path HRMS_Brochure/includes/header.php
New-Item -ItemType File -Force -Path HRMS_Brochure/includes/footer.php
New-Item -ItemType File -Force -Path HRMS_Brochure/index.php

# Download JS files
Invoke-WebRequest -Uri "https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js" -OutFile "HRMS_Brochure/assets/js/jquery.min.js"
Invoke-WebRequest -Uri "https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" -OutFile "HRMS_Brochure/assets/js/bootstrap.min.js"
Invoke-WebRequest -Uri "https://cdn.jsdelivr.net/particles.js/2.0.0/particles.min.js" -OutFile "HRMS_Brochure/assets/js/particles.min.js"
Invoke-WebRequest -Uri "https://cdnjs.cloudflare.com/ajax/libs/animejs/3.2.1/anime.min.js" -OutFile "HRMS_Brochure/assets/js/anime.min.js"
Invoke-WebRequest -Uri "https://cdnjs.cloudflare.com/ajax/libs/gsap/3.7.1/gsap.min.js" -OutFile "HRMS_Brochure/assets/js/gsap.min.js"
