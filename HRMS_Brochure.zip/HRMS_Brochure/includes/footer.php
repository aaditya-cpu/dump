<!-- Custom scripts -->
<script src="../assets/js/jquery.min.js"></script>
<script src="../assets/js/bootstrap.min.js"></script>
<script src="../assets/js/particles.min.js"></script>
<script src="../assets/js/anime.min.js"></script>
<script src="../assets/js/gsap.min.js"></script>
<script src="../assets/js/script.js"></script>

</body>
</html>
