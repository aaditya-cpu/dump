$(document).ready(function() {
    $('.option').click(function() {
        var answer = $(this).data('answer');
        var bubbleContainer = $('<div>', { class: 'bubble-container user-response' });
        var bubble = $('<div>', { class: 'bubble' }).text(answer === 'yes' ? 'Yes' : 'No');
        bubbleContainer.append(bubble);

        if(answer == 'yes') {
            bubbleContainer.append($('<p>').text('Scroll Up'));
        } else {
            bubbleContainer.append($('<p>').text('Feel free to scroll up'));
        }

        $('#conversation').append(bubbleContainer);

        // Using Anime.js for scrolling
        anime({
            targets: 'body',
            scrollTop: 0,
            duration: 2000,
            easing: 'easeInOutQuad'
        });
    });
});
