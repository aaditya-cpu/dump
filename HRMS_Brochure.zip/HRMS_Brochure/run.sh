#!/bin/bash

# Directories
mkdir -p HRMS_Brochure/assets/{images,css,js}
mkdir -p HRMS_Brochure/includes

# CSS and JS Files
touch HRMS_Brochure/assets/css/style.css
touch HRMS_Brochure/assets/js/script.js

# PHP Files
touch HRMS_Brochure/includes/header.php
touch HRMS_Brochure/includes/footer.php
touch HRMS_Brochure/index.php

# Download JS Libraries

# JQuery
wget -P HRMS_Brochure/assets/js/ https://code.jquery.com/jquery-3.6.0.min.js

# Bootstrap
wget -P HRMS_Brochure/assets/js/ https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js

# Anime.js
wget -P HRMS_Brochure/assets/js/ https://cdnjs.cloudflare.com/ajax/libs/animejs/3.2.1/anime.min.js

# GSAP
wget -P HRMS_Brochure/assets/js/ https://cdnjs.cloudflare.com/ajax/libs/gsap/3.9.1/gsap.min.js

# Particles.js
wget -P HRMS_Brochure/assets/js/ https://cdn.jsdelivr.net/particles.js/2.0.0/particles.min.js

echo "Structure has been set up successfully!"
